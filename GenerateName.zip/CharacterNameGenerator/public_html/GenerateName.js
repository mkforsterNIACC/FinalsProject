function nameGenerator() {
    var charname = "";
    for (counter = 1; counter <= 2; counter++) {
        var character = characterset[Math.floor(Math.random() * characterset.length)];
        charname += character;
    }
    return charname;
}
var characterset = ["Witch","Poison","Cauldron","Sword","Spell","Wizard","Magic","Shield","Shoe","Cat","Owl","Lizard","Mouse","Rat","Sparkle","Fire","Water"];
var counter;
var userName = nameGenerator();
var play = confirm("Would you like to generate a name?");
if (play === true){
    alert("Yay!!!!");
    alert("Your character's name is " + userName + "!");
    document.write("Thanks for playing :)" + "<br>" + "Hit refresh to play again!");
}else {
    document.write("But whyyyy??? It's fun!!!");
}




